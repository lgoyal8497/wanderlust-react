export const backendUrlLogin = `http://localhost:4000/Wanderlust_Server/UserAPI/userLogin`;

export const backendUrlHotDeals = 'http://localhost:4000/Wanderlust_Server/ViewAPI/hotDeals';

export const backendUrlSearch='http://localhost:4000/Wanderlust_Server/ViewAPI/getDestinations/';

export const backendUrlRegister = "http://localhost:4000/Wanderlust_Server/UserAPI/newRegistration/";

export const getBookingUrl = "http://localhost:4000/Wanderlust_Server/ViewAPI/getPlannedTrips/";

export const cancelBookingUrl="http://localhost:4000/Wanderlust_Server/BookingAPI/cancelBooking/";

export const bookingUrl ="http://localhost:4000/Wanderlust_Server/ViewAPI/getDestinationForBooking/";

export const postUrl ="http://localhost:4000/Wanderlust_Server/BookingAPI/newBooking";