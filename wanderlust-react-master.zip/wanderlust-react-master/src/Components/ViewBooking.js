import React, { Component } from "react";
import axios from "axios";
import "../custom2.css";
import "../custom.css";
import { Link } from "react-router-dom";

import {cancelBookingUrl,getBookingUrl} from "../BackendURL";
import {Dialog} from 'primereact/dialog';
import {Button} from 'primereact/button';

//Shows all the confirmed bookings of the user.
class ViewBooking extends Component{
    constructor(props) {
    super(props);
    this.state={
        bookingArr : [],       
        errorMessage:"",
        successMessage:"",
        visible:false,
        currentBookingId:null,
        currentBooking:[]    
    }
}

    //Shows dialog box.
    onClick = () => {
        this.setState({visible: true});
    };

    //Hides dialog box.
    onHide = () => {
        this.setState({visible: false});
    }

    //To display confirmed bookings after page has loaded.
    componentDidMount(){
        this.getBookedTrips();
    }

    //Fetches confirmed booking details of a user from backend.
    getBookedTrips = () => {
        this.setState({bookingArr:[]})
        
        axios.get(getBookingUrl+sessionStorage.getItem("userId"))
            .then((response) => {
                this.setState({bookingArr:response.data,errorMessage:""})
            })
            .catch((error)=> {
                if(error.response){
                    this.setState({errorMessage:error.response.data.message,successMessage:""})
                }
                else{
                    this.setState({errorMessage:"Couldn't connect to server",successMessage:""})
                }
            })
    }

    //Cancellation of a booking.
    cancelBooking = () => {
        this.onHide();
        axios.post(cancelBookingUrl+this.state.currentBookingId)
            .then((response)=>{
                this.getBookedTrips();
                this.setState({successMessage:response.data,errorMessage:""})
            })
            .catch((error) => {
                if(error.response){
                    this.setState({errorMessage:error.response.data.message,successMessage:""})
                }
                else{
                    this.setState({errorMessage:"Couldn't connect to server",successMessage:""})
                }
            })
    }

    //Shows dialog box to ask for confirmation of the cancellation
    confirmCancellation = (event) =>{
        let currentBooking=event.target.value.split(",");
        this.setState({visible:true,currentBookingId:event.target.name,currentBooking:currentBooking});
    }


    //Renders all the booking details of a user on browser.
    render() {

        const footer =(
            <div>
                <Button label="BACK" onClick={this.onHide}></Button>
                <Button label="CONFIRM CANCELLATION" onClick={this.cancelBooking}></Button>
            </div>
        );

        return(
            <div className="container-fluid booking-page">
            <div className="card package-card border-0">
            <div className="card-header">
                <h2 className="text-center">PLANNED TRIPS</h2> 
            </div>
            <div className="card-body">
            {this.state.successMessage ?
                <h4 className="text-success text-center">{this.state.successMessage}</h4>
                :null
            }
            {this.state.bookingArr.length?
                this.state.bookingArr.map((ele,index) => 
                
                <div key={index} className="card package-card">
                    <div className="card-header">
                        <h3>Booking ID :{ele.bookingId}</h3>
                        <h3>Trip to {ele.destination.destinationName}</h3>
                    </div>                           
                    <div className="package-card card-body">
                        <div className="row">
                            <div className="col-md-4">
                                <span className="font-weight-bold">Trip Starts on: </span>{ele.checkIn}
                            </div>
                            <div className="col-md-4">
                            <span className="font-weight-bold">Fare Details: </span>${ele.totalCost}
                            </div> 
                        </div>
                        <div className="row">
                            <div className="col-md-4">
                                <span className="font-weight-bold">Trip Ends on: </span>{ele.checkOut}
                            </div>
                            <div className="col-md-4">
                                <span className="font-weight-bold">Number Of Travellers: </span>{ele.noOfPeople}
                            </div> 
                        </div>
                    </div>
                    <div className="card-footer text-center">
                        <button name={ele.bookingId} value={ele.checkIn+","+ele.checkOut+","+ele.totalCost} type="button" className="btn btn-danger" onClick={this.confirmCancellation}>CANCEL BOOKING</button>
                    </div>
                    <div>
                        {this.state.visible?
                            <Dialog
                                className="dialog-box bg-white" 
                                footer={footer} 
                                header="CONFIRM CANCELLATION"
                                onHide={this.onHide} 
                                visible={this.state.visible}
                                dismissableMask>
                                <div className="container">
                                    <span className="text-danger">Are you sure you want to cancel your trip?</span><br/>
                                    <span>Trip start Date: {this.state.currentBooking[0]}</span><br/>
                                    <span>Trip End Date  : {this.state.currentBooking[1]}</span><br/>
                                    <span>Refund Amount  : {this.state.currentBooking[2]}</span>
                                </div>
                            </Dialog>                       
                        :null}
                    </div>                                                       
                </div>) :
                <div className="text-center">
                    <h3 className="text-danger text-center">{this.state.errorMessage}</h3><br/>
                    <Link to="/" type="button" className="btn btn-info" >CLICK HERE TO START BOOKING</Link>
                </div>
                }
                    </div>
                 </div>
            </div>
        )}
        
}

export default ViewBooking;