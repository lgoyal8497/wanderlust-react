import React, { Component } from 'react';
import axios from 'axios';
import "../custom.css";

import { Redirect } from "react-router-dom";

import { InputText } from 'primereact/inputtext';
import {Fieldset} from 'primereact/fieldset';
import {Link } from "react-router-dom";
import { bookingUrl ,postUrl} from "../BackendURL";

//To display booking component
class Book extends Component {
    
    constructor(props) {
        super(props);

        this.state = { 

            formValue :{
                checkIn:"",
                checkOut:"",
                noOfPeople:"",
                totalCost:"",
                destination:{
                    destinationId:this.props.match.params.destinationId
                },
                users:{
                    userId:sessionStorage.getItem("userId"),
                    userName:sessionStorage.getItem("userName")
                }
            },

            destination:{},

            formErrorMessage: {
                checkInError: "",
                noOfPeopleError: "",
            },

            formValid: {
                checkInValid: false,
                noOfPeopleValid: false,
                buttonActive: false,
            },

            bookedTrip:"",

            cost:0,

            successMessage:"",
            errorMessage:"",    
            
            checked:false,
            goHome:false,
            booked:false

        }

     }

     //To set the form values to corresponding form fields & call the validate functions
    handleChange = event => {
    
        let name=event.target.name;
        let value=event.target.value;
        let {formValue}=this.state;
        this.setState({formValue:{...formValue,[name]:value}});
        this.validateField(name,value);
    };

    //To validate all the form data
    validateField = (name,value) => {
        let {formErrorMessage}=this.state;
        let {formValid}=this.state;

        switch (name) {
            case "noOfPeople":

                if(value===""){
                    formErrorMessage.noOfPeopleError="Field Required";
                    formValid.noOfPeopleValid=false;
                }                
                else if(value>5 || value<1){
                    formErrorMessage.noOfPeopleError="Minimum of 1 and a maximum of 5 people can go on this trip";
                    formValid.noOfPeopleValid=false;
                }
                else if(value>this.state.destination.availability){
                    formErrorMessage.noOfPeopleError="Requested number of seats are not available";
                    formValid.noOfPeopleValid=false;
                }
                else{
                    formErrorMessage.noOfPeopleError="";
                    formValid.noOfPeopleValid=true;
                    this.calculateCost(value);
                }
                
                break;
                          
            case "checkIn":

                const date= new Date(value);
                if(value===""){
                    formErrorMessage.checkInError="Field Required";
                    formValid.checkInValid=false;
                }
                else if(date<new Date()){
                    formErrorMessage.checkInError="The Check-In Date Should be after today and a valid date ";
                    formValid.checkInValid=false;
                }
                else{
                    formErrorMessage.checkInError="";
                    formValid.checkInValid=true;
                    
                }
                break;

            default:
                break;
        }

        

        formValid.buttonActive=formValid.checkInValid && formValid.noOfPeopleValid;
        this.setState({formErrorMessage:formErrorMessage,formValid:formValid,successMessage:"",errorMessage:""});
    }

    //To submit the form and call book trip function
    handleSubmit = event => {

        let {formValue}=this.state;
        formValue.totalCost=this.state.cost;
        this.setState({formValue:formValue})
      
        event.preventDefault();
        this.bookTrip();
    };

    //To calculate the cost based on number of travellers
    calculateCost = (value) => {
        let cost=0;
        if(this.state.destination.discount===0){
            cost= (this.state.destination.chargePerPerson)*value;
            if(this.state.flightIncluded){
                cost= (this.state.destination.chargePerPerson+this.state.destination.flightCharge)*value;
             }
        }
        else{
            cost= (this.state.destination.chargePerPerson)*value*(1-this.state.destination.discount*0.01);
            if(this.state.flightIncluded){
           cost= (this.state.destination.chargePerPerson+this.state.destination.flightCharge)*value*(1-this.state.destination.discount*0.01);
            }
        }
        
        this.setState({cost : cost});
    }

    //To send and axios post request for confirming the booking
    bookTrip = () => {
         let msg="Booking Confirmed!!!";
         axios.post(postUrl,this.state.formValue)
            .then((response) => {
                this.setState({bookedTrip:response.data,successMessage:msg,errorMessage:"",booked:true})
            })
            .catch((error) => {
                if(error.response){
                    this.setState({errorMessage:error.response.data.message,successMessage:""});
                }
                else{
                    this.setState({errorMessage:"Couldn't connect to server",successMessage:""});
                }
            })

    }
    
    //To call get destination Details method
    componentDidMount(){
         this.getdestinationDetails();
     }

     //To send an axios get request to fetch destination details
    getdestinationDetails = () =>{
        axios.get(bookingUrl+this.props.match.params.destinationId)
        .then((response) => {
            this.setState({destination: response.data})
           
        })
        .catch((error) => {})
    }

    //To set goHome state as true for redirecting to home page
    goHome = () =>{
        this.setState({goHome:true})
        
    }

    //To calculate check-Out date & to format it
    calculateDate(checkInDate,noOfNights){
        var checkDays = new Date(checkInDate)
        const months=["January","February","March","April","May","June","July","August","September","October","November","December"]
        checkDays.setDate(checkDays.getDate()+noOfNights);
        let formattedDate=months[checkDays.getMonth()]+" "+checkDays.getDate()+","+checkDays.getFullYear();
        return formattedDate;

    }

    //To set checked state as true for toggle button
    onChangeState=()=>{
        this.setState({checked:!this.state.checked})
    }

    //To include flight cost in total cost based on toggle button state
    flightAddition=()=>{
        let{cost}=this.state;
        if(this.state.checked){
            this.setState({cost:(cost-this.state.destination.flightCharge*this.state.formValue.noOfPeople)})

        }
        else{
            this.setState({cost:(cost+this.state.destination.flightCharge*this.state.formValue.noOfPeople)})

        }
    }

    //To format the cost
    formatter=new Intl.NumberFormat('en-US' ,{
        style:"currency",
        currency:"USD"
    });



    render() {

        if(this.state.goHome){
            return <Redirect to="/"/>
        }
        return (
    
            <div className="container mt-3 book-page booking-page">
                <div className="row mb-3 mt-5">
                    <div className="col-md-6 mt-1 pt-5">

                    <h3 className="display-5">{this.state.destination.destinationName}</h3><br/>
                        {this.state.destination.details!=null?
                        <Fieldset className="fieldset p-fieldset" legend="Overview" toggleable={true} collapsed={true}>
                            {this.state.destination.details.about}
                        </Fieldset>:null}
                        {this.state.destination.details!=null?
                        <Fieldset className="fieldset p-fieldset" legend="Package Inclusion" toggleable={true} collapsed={true}>
                            <ul className="left">
                                {this.state.destination.details.packageInclusion.split(",").map( (ele,i) => <li key={i}>{ele}</li>)}
                            </ul>
                        </Fieldset>
                        :null}
                         {this.state.destination.details!=null?
                        <Fieldset className="fieldset p-fieldset" legend="Itinerary" toggleable={true} collapsed={true}>
                            <ul>
                                <li key="abc"><h6>Day 1</h6><div>{this.state.destination.details.itinerary.firstDay}</div></li>
                                {this.state.destination.details.itinerary.restOfDays.split(",").map((ele,i) =>
                                     <li key={i}><h6>Day {i+2}</h6><div>{ele}</div></li>)}
                                <li key="xyz"><h6>Day {this.state.destination.details.itinerary.restOfDays.split(",").length+2}</h6><div>{this.state.destination.details.itinerary.lastDay}</div></li>
                            </ul>
                            <p className="text-danger">**This itinerary is just a suggestion and can be modified as per your requirement.</p>
                            <Link to="/">Contact Us  </Link><span>for more details.</span>
                        </Fieldset>
                        :  null}
                    </div>
                    <div className=" col-md-6 mt-1 pt-5">
                        <div className="card bg-light">
                            <div className="card-body">
                            <form className="form text-left" onSubmit={this.handleSubmit}>
                                <div className="form-group">
                                    <label>Number Of Travellers</label>
                                    <InputText name="noOfPeople" className="form-control" type="number" onChange={this.handleChange}></InputText>
                                    <span className="text-danger">{this.state.formErrorMessage.noOfPeopleError}</span>
                                </div>
                                <div className="form-group">
                                    <label>Trip Start Date</label>
                                    <InputText name="checkIn" className="form-control" type="date" onChange={this.handleChange}></InputText>
                                    <span className="text-danger">{this.state.formErrorMessage.checkInError}</span>
                                </div>
                                <div className="custom-control custom-switch">
                                    <input 
                                        type="checkbox" 
                                        className="custom-control-input" 
                                        onChange={this.flightAddition} 
                                        onClick={this.onChangeState} 
                                        name="id"
                                        value={this.state.checked} 
                                        id="custom"></input>
                                    <label 
                                        className="custom-control-label"
                                         htmlFor="custom">Include Flights</label>
                                </div>

                                {this.state.formValid.noOfPeopleValid?            
                                    <h3>You Pay: {this.formatter.format(this.state.cost)}</h3>:null
                                }
                                {this.state.formValid.checkInValid?            
                                    <h6>Your Trip ends on: {this.calculateDate(this.state.formValue.checkIn,this.state.destination.noOfNights)}
                                    </h6>:null
                                }<br/>
                                <button className="btn btn-primary btn-block" type="submit" disabled={!this.state.formValid.buttonActive}>CONFIRM BOOKING</button>
                                <button className="btn btn-info btn-block " type="button" onClick={this.goHome}>GO BACK</button>
                            </form>
                            
                            </div>
                        </div>
                    </div>
                </div>
                {this.state.booked?
                <div className="row mb-3 mt-5 offset-md-1"> 
                    {this.state.errorMessage?  
                    <h3 className="text-danger">{this.state.errorMessage}</h3>:
                    <React.Fragment>
                        <h3 className="bg-white">{this.state.successMessage}</h3>
                        <h3 className="text-success bg-white">Congratulations!! Trip planned to {this.state.destination.destinationName}</h3>
                        <h3 className="bg-white">Trip starts on : {this.state.formValue.checkIn}</h3>
                        <h3 className="bg-white">Trip ends on : {this.state.bookedTrip.checkOut}</h3>
                        <Link className="btn btn-info" to={"/viewBookings/"+sessionStorage.getItem("userId")}>
                            Click here to view your bookings
                        </Link>
                    </React.Fragment>
                }
                </div>
                :null}
            </div>
        );
    }
}

export default Book;