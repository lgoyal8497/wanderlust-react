import React, { Component } from "react";
import "../index.css";
import Home from "./Home";
import Book from "./Book";
import Login from "./Login";
import Register from "./Register";
import ViewBooking from "./ViewBooking";
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import Search from "./Search";
import 'bootstrap/dist/css/bootstrap.css';
import {Dialog} from 'primereact/dialog';
import {Button} from 'primereact/button';

//Displays navbar on top of the screen
class NavBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      logged_userId: sessionStorage.getItem("userId"),
      logged_userName: sessionStorage.getItem("userName"),
      dialog_visible: false,
      logged_out: false
    };
  }

  //Shows dialog box.
  onClick = () => {
    this.setState({ dialog_visible: true });
  };

  //Hides dialog box.
  onHide = () => {
    this.setState({ dialog_visible: false });
  };

  //Logs out the user.
  logout = () => {
    this.setState({ dialog_visible: false });
    sessionStorage.clear();
    this.setState({ logged_out: true });
    window.location.reload();
  };

  //Asks for confirmation of logout using dialog
  confirm_logout = () => {
    this.setState({ dialog_visible: true });
  };

  //Renders the navbar on the screen
  render() { 
    return (
        <Router>
          {/* <div className="container-fluid"> */}
          <div className="App">
            <nav className="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
              <div className="navbar-header">
                <Link className="navbar-brand" to="/">
                  Start Wandering
                </Link>
               
              </div>
              <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                  <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse" id="collapsibleNavbar">
              <ul className="navbar-nav ml-auto">
                {this.state.logged_userId ? (
                  <li className="nav-item">
                    <Link className="nav-link" to="">
                      Welcome {this.state.logged_userName}
                    </Link>
                  </li>
                ) : null}
                <li className="nav-item">
                  <a href="/#hotDeals" className="scrollLink nav-link" to="/packages">
                    Hot Deals{" "}
                  </a>
                  {/* <a id="hotDeals">hotDeals</a> */}
                </li>
                <li className="nav-item">
                  {sessionStorage.getItem("userId")!=null?
                    <Link className="nav-link" to={"/viewBookings/"+sessionStorage.getItem("userId")}>
                      Planned Trips
                    </Link>:null}
                </li>

                {!this.state.logged_userId ? (
                  <li className="nav-item">
                    <Link className="nav-link" to="/login">
                      {" "}
                      Login
                    </Link>
                  </li>
                ) : null}
                {this.state.logged_userId ? (
                  <li className="nav-item">
                    <Link className="nav-link" onClick={this.confirm_logout} to="">
                      {" "}
                      Logout
                    </Link>
                  </li>
                ) : null}
              </ul>
              </div>
            </nav>
            <div>
                  {this.state.dialog_visible?
                            <Dialog
                                className="dialog-box" 
                                footer={<div>
                                  <Button className="p-button-secondary" label="BACK" onClick={this.onHide}></Button>
                                  <Button className="p-button-danger" label="CONFIRM LOGOUT" onClick={this.logout}></Button>
                              </div>} 
                                header="CONFIRM LOGOUT"
                                onHide={this.onHide} 
                                visible={this.state.dialog_visible}
                                dismissableMask>
                                <div className="container">
                                    <span className="text-danger">Are you sure you want to logout?</span>
                                </div>
                            </Dialog>                       
                        :null}
                    </div>          

            <Switch>
            
              <Route exact path="/" component={Home}></Route>
              <Route exact path="/login" component={Login}></Route>
              <Route exact path="/register" component={Register}></Route>
              <Route exact path="/packages/:continent" component={Search}></Route>
              <Route exact path="/book/:destinationId" component={Book}></Route>
              <Route path="/viewBookings/:userId" component={ViewBooking}></Route>
            </Switch>
          </div>
        </Router>
      
    );
  }
}
export default NavBar;
