import React, { Component } from 'react';
import {Sidebar} from 'primereact/sidebar';
import {Accordion,AccordionTab} from 'primereact/accordion';
import {ScrollPanel} from 'primereact/scrollpanel';

import {Redirect} from 'react-router-dom';
import "../custom2.css"; 

//For the data to be rendered in search component
class SearchData extends Component {
    
    constructor(props){
        super(props)
        this.state={
            element:this.props.element,
            visible:false,
            bookVisible:false,
            destId:"",
        }
    }

    //To set visible state as true for displaying sidebar
    viewComponent = () => {
        this.setState({visible:true})
    }

    //returns the sidebar component with required data
    viewDetails=()=> {
        
        return(
            <Sidebar 
                visible={this.state.visible}
                position="left"
                baseZindex={1000000}
                showCloseIcon
                dismissable
                closeOnEscape
                className="p-sidebar-md bg-dark text-white"
                onHide={(e) =>this.setState({visible:false})}><br/><br/><br/>
                <h3 className="font-weight-bold text-center">{this.state.element.destinationName}</h3><br/>
                <ScrollPanel className="scrollPanel">
                    
                <Accordion>
                    {this.state.element.details!=null?
                    <AccordionTab header="Package Inclusions">                       
                        <ul className="left">
                            {this.state.element.details.packageInclusion.split(",").map( (ele,i) => <li key={i}>{ele}</li>)}
                        </ul>
                        
                    </AccordionTab>
                    :null}
                    {this.state.element.details!=null?
                    <AccordionTab header="Itinerary">                   
                        <ul>
                            <li key="abc"><h6>Day 1</h6><div>{this.state.element.details.itinerary.firstDay}</div></li>
                                {this.state.element.details.itinerary.restOfDays.split(",").map((ele,i) =>
                                     <li key={i}><h6>Day {i+2}</h6><div>{ele}</div></li>)}
                            <li key="xyz"><h6>Day {this.state.element.details.itinerary.restOfDays.split(",").length+2}</h6><div>{this.state.element.details.itinerary.lastDay}</div></li>
                        </ul>                       
                    </AccordionTab>:null}
                    {this.state.element.details!=null?
                    <AccordionTab header="Highlights">                       
                        <ul className="left">
                            {this.state.element.details.highlights.split(",").map( (ele,i) => <li key={i}>{ele}</li>)}
                        </ul>    
                    </AccordionTab>
                    :null}
                    {this.state.element.details!=null?
                    <AccordionTab header="Tour Pace">                       
                        <ul className="left">
                            {this.state.element.details.pace}
                        </ul>    
                    </AccordionTab>
                    :null}
                </Accordion>
                </ScrollPanel>

            </Sidebar>
        );
    }


    render() {
        //Redirect to booking component on click of book button
        if(this.state.bookVisible){
            return <Redirect to={"/book/"+this.state.destId}></Redirect>
        }

        return (
            <React.Fragment>

            <div  className="card bg-dark package-card">
                        
                        <div className="row cardAlign">
                            <div className="card-img col-md-4 col-md-offset-1 cardImgAlign">
                                <img className="card-img rounded package-image" src={this.state.element.imageURL} alt="Img"></img>
                            </div>
                            <span className="verticalBar"></span>
                            <div className="dynamic-card-body col-md-4 col-offset-md-2 ">
                                
                                <span className="badge bg-info text-white">{this.state.element.noOfNights} Nights</span>
                                <br/>
                                {this.state.element.discount!==0 ?
                                <React.Fragment>
                                <span className="text-danger font-weight-bold">{this.state.element.discount}% Instant Discount</span>
                                <br/>
                                </React.Fragment>
                                :null
                                }
                                
                                <span className="card-text text-light">{this.state.element.details.about}</span><br/>
                            </div>
                            <div className="jumbotron col-md-4 col-offset-md-1 text-center">
                                <h3 className="card-text font-weight-bold">Prices Starting From:</h3><br/>
                                <h4 className="text-success text-center font-weight-bold">${this.state.element.chargePerPerson}</h4>
                                <div><br/>
                                <button className="btn btn-info" onClick={this.viewComponent}>VIEW DETAILS</button><br/><br/>
                                
                                <button className="btn btn-info" value={this.state.element.destinationId} onClick={(e) =>this.setState({bookVisible:true,destId:e.target.value})} >BOOK</button>
                                </div>
                            </div>
                        </div>     
            </div>
            {/* call the viewdetails method if visible is set to true */}
            {this.state.visible?
                this.viewDetails():null}
                </React.Fragment>
            
        );
    }
}

export default SearchData;