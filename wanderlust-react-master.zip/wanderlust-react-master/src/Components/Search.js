import React, { Component } from "react";
import axios from "axios";
import "../custom2.css";
import "../custom.css";
import { backendUrlSearch } from "../BackendURL";

import {Link} from 'react-router-dom';

import {ProgressSpinner} from 'primereact/progressspinner';
import SearchData from "./SearchData";

//This class searches the tour packages based on the continent.
class Search extends Component{
    constructor(props) {
    super(props);
    this.state={
        detailsArr : [],

        filteredArr:[],
        filter:false,

        filterValue:{
            price:10000,
            maxNoOfNights:30
        },

        viewVisible:false,
        
        viewDest:"",
        
        errorMessage:"",
        loading:false
    }
}

    //This function handles changes applied on the range slider to filter packages.
    handleChange= async(event) =>{
        event.preventDefault();
        let name=event.target.name;
        let value=event.target.value;

        let {filterValue}=this.state;
        await this.setState({filterValue:{...filterValue,[name]:value}});
        this.filterApplied();
        this.setState({filteredArr:this.state.detailsArr.filter(item=>(item.chargePerPerson<=this.state.filterValue.price && item.noOfNights<=this.state.filterValue.maxNoOfNights))})
    }

        //This function checks if filter is applied and sets state accordingly.
    filterApplied=() =>{
        if(this.state.filterValue.price!==10000 || !this.state.filterValue.maxNoOfNights!==30){
            this.setState({filter:true});
        }
        else{
            this.setState({filter:false});
        }
    }

    //This function invokes getData() function to display all packages.
    componentDidMount(){
        this.getData();
        this.setState({loading:true});
        this.timeHandler=setTimeout(()=>this.setState({loading:false}),1500)
    }

    //This function fetches data from backend to display.
    getData= () => {
        axios.get(backendUrlSearch+this.props.match.params.continent)
        .then((response) => {
            this.setState({detailsArr: response.data})
        })
        .catch((error) => { if(error.response){
                this.setState({errorMessage:error.response.data.message})
                }
                else{
                    this.setState({errorMessage:"Server Error"})
                }
        })

    }

    
    //This function renders the rangeslider and the filtered packages on the browser.
    render() {
        if(this.state.loading){
            return(
                <div className="row booking-page">
                <div className="col-4 offset-5">
                <ProgressSpinner/>
                </div>
                </div>
            )
        }
        

        return(
            
            <div className="container booking-page">
                {!this.state.errorMessage ?
                    (<div className="card">
                        <div className="card-header">
                        <h2 className="text-dark text-center text-capitalize">Check Out Our Exciting {this.props.match.params.continent} Tour Packages!!!</h2>
                        </div>
                        
                        <div className="jumbotron text-center">
                            <div className="row">
                            <div className="col-md-6">
                                <label className="font-weight-bold">Max Price: $ <span id="price">{this.state.filterValue.price}</span></label>
                                <input type="range" min="1" max="10000" value={this.state.filterValue.price} name="price" className="slider" onChange={this.handleChange}></input>
                            </div>
                            <div className="col-md-6">
                                <label  className="font-weight-bold">Max Number Of Nights:<span id="nights">{this.state.filterValue.maxNoOfNights}</span></label>
                                <input type="range" min="1" max="30" value={this.state.filterValue.maxNoOfNights} name="maxNoOfNights" className="slider" onChange={this.handleChange}></input>
                            </div>
                            
                            </div>
                        </div>
                    
                    
                       {this.state.filter ? 

                        (this.state.filteredArr.length>0 ?

                        this.state.filteredArr.map( (element,i) =>
                            <SearchData
                                element={element}>

                            </SearchData>    
                    ):(<h3 className="text-danger text-center">Sorry! No such packages available currently</h3>))
                    
                    :this.state.detailsArr.map( (element,i) =>
                    
                        <SearchData key={i}
                            element={element}>

                        </SearchData>
                        )
                        }
                   
                    <div className="card-footer">

                    </div>
                        <Link to="/" className="homeLink text-center text-dark font-weight-bold ">GO BACK TO HOME</Link>
                    </div>)

                    :<div className="errorDiv">
                        <h2 className="text-danger text-center font-weight-bold">OOPS!</h2>
                        <h3 className="text-danger text-center font-weight-bold">{this.state.errorMessage}</h3>
                    </div>
                }
            </div>
        );
    }

}

export default Search;