import React, { Component } from "react";
import axios from "axios";

import "../custom.css";

import HotDealsData from "./HotDealsData";
import { backendUrlHotDeals } from "../BackendURL";

//To display Hot Deals component
class HotDeals extends Component{

    state={
        detailsArr : [],
        visible : false,
        errorMessage:""
    }

    //To call getData()
    componentDidMount(){
        this.getData();
    }

    //Sends an axios get request for getting details of destination which are having discount
    getData= () => {
        axios.get(backendUrlHotDeals)
        .then((response) => {
            this.setState({detailsArr: response.data})
        })
        .catch((error) => {if(error.response){
                                this.setState({errorMessage:error.response.data.message})
                        }
                        else{
                            this.setState({errorMessage:"Unable to fetch deals"})
                        }
        })

    }

    render() {

        return(
            <div className="container-fluid mt-5 booking-page" >
                {this.state.detailsArr.map((element,i) =>
                 <HotDealsData key={i}
                    destination={element} 
                    imageURL={element.imageURL} 
                    destinationName={element.destinationName} 
                    discount={element.discount} 
                    details={element.details}
                    destinationId={element.destinationId}>
                </HotDealsData>        
                )}
            </div> 

        );
    }

}

export default HotDeals;