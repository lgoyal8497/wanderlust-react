import React, { Component } from "react";
import axios from "axios";
import { InputText } from "primereact/inputtext";
import {Link } from "react-router-dom";

import { backendUrlRegister } from "../BackendURL";


//This class registers a new user
class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formValue: {
        userName: "",
        emailId: "",
        contactNumber: "",
        password:""
      },
      formErrorMessage: {
        userName: "",
        emailId: "",
        contactNumber: "",
        password:""
      },
      formValid: {
        userName: false,
        emailId: false,
        contactNumber: false,
        password:false,
        buttonActive:false
      },
      
      errorMessage: "",
      successMessage: ""
    };
  }

 
  //This function handles the changes whenever any change is made in input.
  handleChange = event => {
    
       let name=event.target.name;
       let value=event.target.value;

       let{formValue}=this.state;
       this.setState({formValue:{...formValue,[name]:value}});
       this.validateField(name,value);
  };

  //This function validates all the input fields.
  validateField = (fieldName, value) => {

    let {formErrorMessage}=this.state;
    let{formValid}=this.state;

    let namePattern=/^[A-Za-z][A-Za-z ]*$/
    let emailPattern=/^[A-Za-z0-9]+@[A-Za-z0-9]+\.com$/
    let mobilePattern=/^(6|7|8|9)[0-9]{9}$/

    switch(fieldName){
        case 'userName':if(value===""){
                        formErrorMessage.userName="Please enter your name";
                        formValid.userName=false;
                    }
                    else if(!value.match(namePattern)){
                        formErrorMessage.userName="Please enter a valid name";
                        formValid.userName=false;
                    }
                    else{
                        formErrorMessage.userName="";
                        formValid.userName=true;
                    }
                    break;

        case 'emailId':if(value===""){
                        formErrorMessage.emailId="Please enter your email id";
                        formValid.emailId=false;
                    }
                    else if(!value.match(emailPattern)){
                        formErrorMessage.emailId="Please enter a valid email id";
                        formValid.emailId=false;
                    }
                    else{
                        formErrorMessage.emailId="";
                        formValid.emailId=true;
                    }
                    break;

        case 'contactNumber':if(value===""){
                        formErrorMessage.contactNumber="Please enter your contact number";
                        formValid.contactNumber=false;
                    }
                    else if(!value.match(mobilePattern)){
                        formErrorMessage.contactNumber="Please enter a valid contact number";
                        formValid.contactNumber=false;
                    }
                    else{
                        formErrorMessage.contactNumber="";
                        formValid.contactNumber=true;
                    }
                    break;

        case 'password':if(value===""){
                        formErrorMessage.password="Please enter your password";
                        formValid.password=false;
                    }
                    else if(value.length<7){
                        formErrorMessage.password="Password is too weak";
                        formValid.password=false;
                    }
                    else if(value.length>20){
                        formErrorMessage.password="Password exceeds the required length";
                        formValid.password=false;
                    }
                    else if(!value.match(/[A-Z]/)){
                        formErrorMessage.password="Password should contain atleast one uppercase character";
                        formValid.password=false;
                    }
                    else if(!value.match(/[a-z]/)){
                        formErrorMessage.password="Password should contain atleast one lowercase character";
                        formValid.password=false;
                    }
                    else if(!value.match(/[0-9]/)){
                        formErrorMessage.password="Password should contain atleast one digit";
                        formValid.password=false;
                    }
                    else if(!value.match(/[!@#$%^&*]/)){
                        formErrorMessage.password="Password should contain atleast one special charater";
                        formValid.password=false;
                    }
                    else{
                        formErrorMessage.password="";
                        formValid.password=true;
                    }
                    break;

        default: break;
    }

    formValid.buttonActive=formValid.userName&&formValid.emailId&&formValid.contactNumber&&formValid.password;
    this.setState({formErrorMessage:formErrorMessage,formValid:formValid,successMessage:"",errorMessage:""});
    
  };

  
  //This function prevents the page from reloading and calls registerUser() on submitting the form
  handleSubmit = event => {
      
      event.preventDefault();
       this.registerUser();
    };

  

  //This function sends data to backend to store user details in database using axios post method.
  registerUser = () => {
    let message="! You have successfully been registered to WanderLust. Please log in to utilise most of our functionalities..."
    axios.post(backendUrlRegister,this.state.formValue)
      .then((response)=>{this.setState({successMessage:"Congratulations "+response.data+message,errorMessage:""})})
      .catch((error) =>{if (error.response){
                              this.setState({errorMessage:error.response.data.message,successMessage:""})
                         }else{
                                this.setState({errorMessage:'Registration Failed! Please try again',successMessage:""})
                        }
                    })
  };

  //This function is used to render the page on browser.
  render() {
    return (
      <div className="Register booking-page">
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <br />
            <div className="card">
              <div className="card-header bg-custom">
                <h3 className="text-center text-dark font-weight-bold">Sign Up</h3>
              </div>
              <div className="card-body">
                  <form className="form" onSubmit={this.handleSubmit}>
                    <div className="form-group text-left">
                        <label >Name<span className="text-danger">*</span></label>
                        <InputText type="text" name="userName" className="form-control" placeholder="Name should contain only alphabets and space" required onChange={this.handleChange}/>
                        <span className="text-danger">{this.state.formErrorMessage.userName}</span>
                    </div>
                    <div className="form-group text-left">
                        <label>Email Id<span className="text-danger">*</span></label>
                        <InputText type="email" name="emailId" className="form-control" placeholder="Only alphanumeric characters allowed" onChange={this.handleChange}/>
                        <span className="text-danger">{this.state.formErrorMessage.emailId}</span>
                    </div>
                    <div className="form-group text-left">
                        <label>Contact Number<span className="text-danger">*</span></label>
                        <InputText type="number" name="contactNumber" className="form-control" placeholder="Enter only valid Indian number" onChange={this.handleChange}/>
                        <span className="text-danger">{this.state.formErrorMessage.contactNumber}</span>
                    </div>
                    <div className="form-group text-left">
                        <label>Password<span className="text-danger">*</span></label>
                        <InputText type="password" name="password" className="form-control" placeholder="Keep a strong password" onChange={this.handleChange}/>
                        <span className="text-danger">{this.state.formErrorMessage.password}</span>
                    </div>
                    
                    <span className="text-danger <br></br>">*</span><span className="text-left"> marked fields are mandatory</span>
                    <br></br>
                    <br></br>
                    <button type="submit" className="btn btn-lg btn-info" disabled={!this.state.formValid.buttonActive}>Register</button>
                    <br></br>
                    <span className="text-success">{this.state.successMessage}</span>
                    <span className="text-danger">{this.state.errorMessage}</span>
                    <br></br>
                    <br></br>
                    {this.state.successMessage ?
                    <Link to="/login" className="btn btn-medium btn-primary">Click here to Login</Link>
                    : null}
                  </form>
                
               
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Register;
