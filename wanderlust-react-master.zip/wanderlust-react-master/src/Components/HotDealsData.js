import React, { Component } from "react";
import "../custom.css";
import "../custom2.css";
import { Redirect } from "react-router-dom";

import {Dialog} from 'primereact/dialog';
import {Button} from 'primereact/button';
import {ScrollPanel} from 'primereact/scrollpanel';

//To render all the Hot Deals data
class HotDealsData extends Component {
    constructor(props){
        super(props)
        this.state={

            visible :false,
            bookVisible :false,
            redirectLogin:false,

        }
}

//To set visible state as true for displaying dialog box
onShow = () => {
    this.setState({visible: true});
};

//To set visble state as false for hiding dialog box
onHide = () => {
    this.setState({visible: false});
}

//to set redirectLogin as true if user is not loggedIn else set bookVisible as true
bookings =() => {
    if(sessionStorage.getItem("userId")!=null){
        this.setState({bookVisible: true});
    }
    else{
       this.setState({redirectLogin:true})
    }     
}

//To display the content inside the dialog box
dialogContent =(element) =>{

    const highlights=element.details.highlights.split(",");
    const packageinclusion=element.details.packageInclusion.split(",");
    const pace = element.details.pace.split(",");

    return(
        <div className='hotDeals'>
            <div className="container-fluid " >
                <div className="row">
                    <div className="col-md-6 col-sm-6" style={{fontSize:15}}>
                        <h5 className="text-info font-weight-bold">Tour Highlights</h5>
                        <ul>{highlights.map((ele,i) => <li key={i}>{ele}</li>)}</ul>
                    </div>
                    <div className="col-md-6 col-sm-6" >
                        <img className="img-fluid" src={this.props.imageURL} alt="Card cap"></img>
                    </div>          
                </div>
                <br/>
            <div className="row">
                <div className="col-md-6 col-sm-6">
                    <img className="img-fluid" src="assets/aus1.jpg" alt="Card cap"></img>
                </div> 
                <div className="col-md-6 col-sm-6" style={{fontSize:15}}>
                    <h5 className="text-info font-weight-bold">Package Inclusions</h5>
                    <ul>{packageinclusion.map((ele,i) => <li key={i}>{ele}</li>)}</ul>
                </div>          
            </div>
            <br/>
            <div className="row">
                <div className="offset-md-1"  style={{fontSize:15}}>
                    <h5 className="text-info font-weight-bold">Tour Pace</h5>
                    <ul>{pace.map((ele,i) => <li key={i}>{ele}</li>)}</ul>
                </div>
            </div>
        </div>
    </div>
    )
}

    //To return dialog component
    dialog = (element) => {

        //Footer content of dialog box
        const footer =(
            <div className="mb-2">
                <Button label="BOOK" onClick={this.bookings}></Button>
                <Button label="CANCEL" onClick={this.onHide}></Button>
            </div>
        );

    

    return( 
            <Dialog className="dialog-box"
                
                header={<h4 className="text-info text-center mt-2">ITINERARY</h4>}
                footer={footer} 
                onHide={this.onHide} 
                visible={this.state.visible}
                maximizable 
                dismissableMask>
                <ScrollPanel className="scrollPanel">
                    {this.dialogContent(element)}
                </ScrollPanel>
            </Dialog>

    );
}
    render() {

        // Redirect to book page if bookVisible is true
        if(this.state.bookVisible){
            return <Redirect to={"/book/"+this.props.destinationId}></Redirect>
        }
        //Redirect to login page if redirectLogin is true
        else if(this.state.redirectLogin){
            return <Redirect to="/login"></Redirect>
        }    
        return (  
            <div className=" card bg-light package-card text-dark ">
            <div className="card-body row">
                <div className="col-md-4">
                    <img className="package-image img-fluid" src={this.props.imageURL} alt="Card cap" ></img>
                </div>
                <div className=" col-md-6">
                <div className="featured-text text-center text-lg-left">
                <h4 className="card-title">{this.props.destinationName}</h4>
                    <span className="card-text discount">{this.props.discount}% Instant Discount</span><br/>
                    <p className="card-text">{this.props.details.about}</p><br/>
                    <button className="btn btn-info"  onClick={this.onShow}>Check Itinerary</button>
                        <button
                            className="btn btn-info ml-3" 
                            onClick={this.bookings}>Book
                        </button>
                </div>
                   
                    
                </div> 
                {this.dialog(this.props.destination)}

            </div>
            </div>   
        );
    }
}

export default HotDealsData;